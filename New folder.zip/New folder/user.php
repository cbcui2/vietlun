<?php
$dataLog  =  array(
'email' => 'ngggth@gmail.com',
'pass' => 'Nguyen111',
'apps' =>'41158896424',# ID Applikasi nya
);
$UID = '100010340198566';

?>